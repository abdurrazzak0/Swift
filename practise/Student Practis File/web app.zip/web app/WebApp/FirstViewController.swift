//
//  FirstViewController.swift
//  WebApp
//
//  Created by Newgen Brl on 26/1/20.
//  Copyright © 2020 Newgen Brl. All rights reserved.
//

import UIKit

class FirstViewController: UIViewController {
    var webLink: [Link] = []
    override func viewDidLoad() {
        super.viewDidLoad()
        
        webLink = setWebsiteLink()
        // Do any additional setup after loading the view.
    }
    
    
    func setWebsiteLink()-> [Link]{
        var tempLink: [Link] = []
        let l1 = Link(title: "Yahoo", url: "https://yahoo.com")
        let l2 = Link(title: "Google", url: "https://google.com")
        let l3 = Link(title: "bing", url: "https://www.bing.com/")
        let l4 = Link(title: "Duck Duck Go", url: "https://duckduckgo.com/")
        let l5 = Link(title: "Ask", url: "https://www.ask.com/")

        
        tempLink.append(l1)
        tempLink.append(l2)
        tempLink.append(l3)
        tempLink.append(l4)
        tempLink.append(l5)

        return tempLink
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let connection = segue.destination as! WebViewController
        let senderTag = (sender as? UIButton)?.tag
        /*if senderTag == 1 {
            connection.webGetData = webLink[0]
        }else if senderTag == 2{
            connection.webGetData = webLink[1]
        }*/
        
        switch senderTag {
            case 1:
                connection.webGetData = webLink[0]
            case 2:
                connection.webGetData = webLink[1]
            case 3:
                connection.webGetData = webLink[2]
            case 4:
                connection.webGetData = webLink[3]
            case 5:
                connection.webGetData = webLink[4]
            default:
                connection.webGetData = webLink[1]
        }
        
    }

}

