//
//  SecondViewController.swift
//  WebApp
//
//  Created by Newgen Brl on 26/1/20.
//  Copyright © 2020 Newgen Brl. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {
    var webLink: [Link] = []
    override func viewDidLoad() {
        webLink = setWebsiteLink()
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    func setWebsiteLink()-> [Link]{
        var tempLink: [Link] = []

        let l6 = Link(title: "Gmail", url: "https://www.google.com/intl/bn/gmail/about/")
        let l7 = Link(title: "Yahoo Mail", url: "https://login.yahoo.com/")
        let l8 = Link(title: "outlook", url: "https://outlook.live.com/owa/")
        let l9 = Link(title: "mail", url: "https://www.mail.com/int/")

        tempLink.append(l6)
        tempLink.append(l7)
        tempLink.append(l8)
        tempLink.append(l9)
        return tempLink
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
           let connection = segue.destination as! WebViewController
           let senderTag = (sender as? UIButton)?.tag
           switch senderTag {
               case 6:
                   connection.webGetData = webLink[0]
               case 7:
                   connection.webGetData = webLink[1]
               case 8:
                   connection.webGetData = webLink[2]
               case 9:
                   connection.webGetData = webLink[3]
               default:
                   connection.webGetData = webLink[0]
           }
           
       }
}

