//
//  website.swift
//  WebApp
//
//  Created by Newgen Brl on 26/1/20.
//  Copyright © 2020 Newgen Brl. All rights reserved.
//

import UIKit

class website: NSObject {

}
class Link{
    var title: String?
    var url: String?
    
    init(title: String, url: String) {
        self.title = title
        self.url = url
    }
}
