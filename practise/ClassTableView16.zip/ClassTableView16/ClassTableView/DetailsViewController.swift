//
//  DetailsViewController.swift
//  ClassTableView
//
//  Created by Tanim on 16/1/20.
//  Copyright © 2020 USER. All rights reserved.
//

import UIKit
import SafariServices // Imported the new framework

class DetailsViewController: UIViewController {
    var detailsvideo: video?

    @IBOutlet weak var thumb: UIImageView!
    @IBOutlet weak var titleLab: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        thumb.image = detailsvideo?.image
        titleLab.text = detailsvideo?.title
    }
    
// OPEN URL WITH SAFARI VC
    @IBAction func OpenURLAC(_ sender: Any) {
        if let video = detailsvideo{
            let vidUrl = URL(string: video.url!)
            let safariVC = SFSafariViewController(url: vidUrl!)
            present(safariVC,animated: true, completion: nil)
        }
    }


}
