//
//  ViewController.swift
//  ClassTableView
//
//  Created by Tanim on 15/1/20.
//  Copyright © 2020 USER. All rights reserved.
//

import UIKit

class ViewController: UIViewController{
    
@IBOutlet weak var tableView: UITableView!
    var videos: [video] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        videos = createVideoArray()
        tableView.delegate = self
        tableView.dataSource = self
    }

    
    func createVideoArray() -> [video]{
        var tempArray:[video] = []
        
        let v1 = video(image:#imageLiteral(resourceName: "img1"), title: "Swift Tutorial Part 01", url: "https://fokkezb.nl/2013/05/20/titanium-studio-shortcuts/", description: "You can learn Moere Man")
        let v2 = video(image:#imageLiteral(resourceName: "img2"), title: "Swift Tutorial Part 02", url: "www.google.com", description: "Hiiiiiii Man")
        let v3 = video(image:#imageLiteral(resourceName: "img3"), title: "Swift Tutorial Part 03", url: "www.google.com", description: "Hi How are you Man")
        let v4 = video(image:#imageLiteral(resourceName: "img2"), title: "Swift Tutorial Part 04", url: "www.google.com", description: "Beginner")
        let v5 = video(image:#imageLiteral(resourceName: "img1"), title: "Swift Tutorial Part 01", url: "www.google.com", description: "You can learn Moere Man")
        let v6 = video(image:#imageLiteral(resourceName: "img2"), title: "Swift Tutorial Part 02", url: "www.google.com", description: "Hiiiiiii Man")
        let v7 = video(image:#imageLiteral(resourceName: "img3"), title: "Swift Tutorial Part 03", url: "www.google.com", description: "Hi How are you Man")
        let v8 = video(image:#imageLiteral(resourceName: "img2"), title: "Swift Tutorial Part 04", url: "www.google.com", description: "Beginner")
        tempArray.append(v1)
        tempArray.append(v2)
        tempArray.append(v3)
        tempArray.append(v4)
        tempArray.append(v5)
        tempArray.append(v6)
        tempArray.append(v7)
        tempArray.append(v8)
        return tempArray
    }
}

extension ViewController :UITableViewDelegate, UITableViewDataSource{
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return videos.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let  video = videos [indexPath.row]
        let  cell = tableView.dequeueReusableCell(withIdentifier: "TableCell") as! TableViewCell
        cell.setVideo(video: video)
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let videorow = videos [indexPath .row]
        print(indexPath.row)
        let sb = storyboard?.instantiateViewController(withIdentifier:"Details") as! DetailsViewController
        sb.detailsvideo = videorow
        self.navigationController?.pushViewController(sb, animated: true)
    }
}
