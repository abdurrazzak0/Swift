//
//  ForthViewController.swift
//  January 26
//
//  Created by Tanim on 27/1/20.
//  Copyright © 2020 USER. All rights reserved.
//

import UIKit

class ForthViewController: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    @IBAction func redButtonClicked(sender: AnyObject) {
        if sender.tag == 0 {
           // print("First Button")
        }else{
            //print("second button")
        }
        self.performSegue(withIdentifier: "seg1", sender: sender)
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        super.prepare(for: segue, sender: sender)
        if segue.identifier == "seg1" {
            let senderButton = sender as! UIButton
            //print(senderButton.tag)
            let buttonTag = senderButton.tag
           
            if buttonTag == 0 {
                let controller = segue.destination as? DetailsViewController
                controller?.ab = "https://www.google.com/"
            }else{
                let controller = segue.destination as? DetailsViewController
                controller?.ab  = "https://login.yahoo.com/"
            }

        }
    }

}
