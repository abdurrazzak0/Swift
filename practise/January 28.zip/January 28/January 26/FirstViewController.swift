//
//  FirstViewController.swift
//  January 26
//
//  Created by Tanim on 26/1/20.
//  Copyright © 2020 USER. All rights reserved.
//

import UIKit

struct student{
    let name: String
    let std_id: String
    let img: String
    let id: Int
    
    init (json: [String: Any]){
        id = json["id"] as? Int ?? -1
        name = json["name"] as? String ?? ""
        std_id = json["std_id"] as? String ?? ""
        img = json["img"] as? String ?? ""
    }
}

class FirstViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        let jsonUrlString = "http://amadertiger.com/REST_API/cricket.php"
        guard let url = URL(string: jsonUrlString) else{return}
        
        URLSession.shared.dataTask(with: url){ (data, response, err) in
            
            guard let data = data else{return}
            
            do{
                let json = try JSONSerialization.jsonObject(with: data, options: .mutableContainers)
                
                print(json)
            }catch let JsonErr{
                print("The error for json serialization is \(JsonErr)")
            }
        }.resume()

    }


}

