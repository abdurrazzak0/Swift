//
//  ThirdViewController.swift
//  January 26
//
//  Created by Tanim on 26/1/20.
//  Copyright © 2020 USER. All rights reserved.
//

import UIKit

class ThirdViewController: UIViewController {

    var webCollection: [websites] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.title = "Value View"
        
        webCollection = CreateArray()
    }
    
    func CreateArray() -> [websites]{
        var temp : [websites] = []
        let v1 = websites(title: "Google", weburl: "https://www.google.com/")
        let v2 = websites(title: "Yahoo", weburl: "https://login.yahoo.com/")
        
        temp.append(v1)
        temp.append(v2)
        print(temp)
        return temp
    }

    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let nvc = segue.destination as! WebAppViewController
        if (segue.identifier == "Seg1") {
            nvc.dataStore = webCollection[0]
        }else{
            nvc.dataStore = webCollection[1]
        }
        
    }
    

}
