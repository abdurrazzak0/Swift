//
//  Cell.swift
//  ClassTableView
//
//  Created by Tanim on 15/1/20.
//  Copyright © 2020 USER. All rights reserved.
//

import UIKit

class Cell: NSObject {

}
class video{
    var image: UIImage?
    var title: String?
    var url: String?
    var description: String?
    
    init(image: UIImage, title: String, url: String, description: String) {
        self.image = image
        self.title = title
        self.url = url
        self.description = description
    }
}
