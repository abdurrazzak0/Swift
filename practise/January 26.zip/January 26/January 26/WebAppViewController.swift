//
//  WebAppViewController.swift
//  January 26
//
//  Created by Tanim on 26/1/20.
//  Copyright © 2020 USER. All rights reserved.
//

import UIKit
import WebKit

class WebAppViewController: UIViewController {
    var dataStore:websites?
    @IBOutlet weak var webView: WKWebView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.title = "Let's watch"
        let Name = dataStore?.title
        let URL = dataStore?.weburl
        print("The site name \(Name!) and url is \(URL!)")
        let url = NSURL(string: URL!)
        let request = NSURLRequest (url: url! as URL)
        
        webView.navigationDelegate = self as? WKNavigationDelegate
        webView.load(request as URLRequest)
    }

}
