//
//  SecondViewController.swift
//  January 26
//
//  Created by Tanim on 26/1/20.
//  Copyright © 2020 USER. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

