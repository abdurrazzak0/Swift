import UIKit

let b = 10
var a = 5

a = 20

print(a)
//Modulus
let x = -9
let y = 4

print(x%y)

// Unary Minus and plus
let three = 3
let negative = +three
let positive = -negative

var M = 1

M -= 2
print(M)
// Comparison
if 1 < 2 {
    print("true")
}else{
    print("false")
}

if (2, "Apple") == (2, "Apple"){
    print("true")
}else{
    print("false")
}

for index in 1...10 {
    print("index \(index) times 4 \(index * 4)")
}

let  names = ["Book","Pen","bank", "School"]
let namescount = names.count

for i in 0..<namescount {
    print(names[i])
}

for name in names [..<3]{
    print(name)
}
// Logical operator
let allowedEntry = false

if !allowedEntry {
    print("Access Denied")
}else{
    print("Accessß")
}

let username = false
let password = false
let email = true

if username && (password || email){
    print("Welcome")
}else{
    print("You have no access")
}

let singleLine = """


I love bangladesh, \

Hellow Man
"""

print(singleLine)

let heart = "\u{1F496}"

print(heart)

for charecter in "CAT!@\u{1F496}😛"{
    print(charecter)
}

let catArray: [Character] = ["C", "A","🧑‍🦰"]

let sString = String(catArray)
print(sString)

var welcome = "Hello"
welcome.insert("@", at: welcome.endIndex)
print(welcome)
