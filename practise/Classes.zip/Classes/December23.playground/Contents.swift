import UIKit

class MacBook{
    var year: Int
    var color: String
    init(year: Int, color: String) {
        self.year = year
        self.color = color
    }
}

let myMacbook = MacBook(year: 2017, color: "Space Gray")
print(myMacbook.color)
let stolenMac = myMacbook //pass by reference
stolenMac.color = "Red"
print(myMacbook.color)

struct iPhone{
    var model: Int
    var color: String
}
let myiPhone = iPhone(model: 10, color: "silver")

var stoleniPhone = myiPhone // Pass by value
stoleniPhone.color = "Space Gray"
print(myiPhone.color)

// Inherit Class
class Parent{
    func ParentMethod(){
        print("I am Parent Method")
    }
    func getName(){
        print("Get Parent Name")
    }
}

var p = Parent()
p.ParentMethod()

class Chield:Parent{
    func ChieldFunction(){
        print("I am chield Method")
    }
    override func getName() {
        print("Get Chield Name")
    }
}
var c = Chield()
c.ChieldFunction()
c.getName()
c.ParentMethod()

// Enumeration
/*
 enum EnamName{
 case 1st case
 case 2nd case
 case 3rd case
 case 4th case
 }
 */
enum compasspoint{
    case north
    case south
    case east
    case west
}

var directiontoGo = compasspoint.east
print(directiontoGo)

directiontoGo  = .west

switch directiontoGo {
case .north:
    print("Go North")
case .south:
    print("Go south")
case .east:
    print("Go east")
case .west:
    print("Go west")
}

// closure extended
let names = ["Dalim", "Tanim", "Ashraful", "Mashrafi","Mushfiq"]

func backward (s1: String, s2: String) -> Bool{
    return s1 < s2
}

var reverseNames = names.sorted(by: backward)

print(reverseNames)

reverseNames = names.sorted(by: {
    (s1: String, s2: String) -> Bool //Parameter -> Return Type
    in
    return s1 > s2  // Statement
})
print(reverseNames)

reverseNames = names.sorted(by: {
    s1,s2 in s1 < s2
})
print(reverseNames)

func makeIncrementer(forIncrement amount: Int) -> () -> Int {
    var runningTotal = 0
    func incrementer() -> Int {
        runningTotal += amount
        
        return runningTotal
    }
    return incrementer
}

let incrementByTen = makeIncrementer(forIncrement: 10)
print(incrementByTen())
print(incrementByTen())
print(incrementByTen())


