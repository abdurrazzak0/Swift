import UIKit

/*let finalSquare = 25
var board = [Int](repeating: 0, count: finalSquare + 1)

board[03] = +08; board[06] = +11; board[09] = +09; board[10] = +02
board[14] = -10; board[19] = -11; board[22] = -02; board[24] = -08

var square = 0
var diceRoll = 0
while square < finalSquare {
    // roll the dice
    diceRoll += 1
    if diceRoll == 7 { diceRoll = 1 }
    print("Moved by rolled amount")
    // move by the rolled amount
    square += diceRoll
    if square < board.count {
        // if we're still on the board, move up or down for a snake or a ladder
        square += board[square]
    }
}
print("Game over!")*/

let someCharacter: Character = "a"
switch someCharacter {
case "a":
    print("The first letter of the alphabet")
case "z":
    print("The last letter of the alphabet")
default:
    print("Some other character")
}

let approximateCount = 50
let countedThings = "moons orbiting Saturn"
let naturalCount: String
switch approximateCount {
case 0:
    naturalCount = "no"
case 1..<5:
    naturalCount = "a few"
case 5..<12:
    naturalCount = "several"
case 12..<100:
    naturalCount = "dozens of"
case 100..<1000:
    naturalCount = "hundreds of"
default:
    naturalCount = "many"
}
print("There are \(naturalCount) \(countedThings).")

// Function
func greet(person: String) ->
    String{
        let greeting = "Hello," + person + "Welcome To the class"
        return greeting
}
print(greet(person: "Abdur Rahman"))
print(greet(person: "Tanim"))

func withoutParam() -> String {
    return "Hello Dear"
}
print(withoutParam())

func greetMany(person: String, alreadyGreeted: Bool) -> String{
    if alreadyGreeted {
        return greet(person: person)
    }else{
        return "Not included his name"
        
    }
}
print(greetMany(person: "ABCDXYZ", alreadyGreeted: true))

func greet1 (person: String){
    print("Hello \(person)")
}
greet1(person: "Kamal")

//Return Multiple type values

func minMax (array: [Int]) -> (min: Int, max: Int){
     var  currentMin = array[0]
     var  currentMax = array[0]
    
    for value in array[1..<array.count] {
        if value < currentMin {
            currentMin = value
        }else if value > currentMax{
            currentMax = value
        }
    }
    return (currentMin, currentMax)
}

/*func minMax(array: [Int]) -> (min: Int, max: Int) {
    var currentMin = array[0]
    var currentMax = array[0]
    for value in array[1..<array.count] {
        if value < currentMin {
            currentMin = value
        } else if value > currentMax {
            currentMax = value
        }
    }
    return (currentMin, currentMax)
}*/

let bounds = minMax(array: [1,-4,20,300,50,100])

print("min is \(bounds.min) and max is \(bounds.max)")

func minMax2(array: [Int]) -> (min: Int, max: Int)? {
    if array.isEmpty {
        return nil
    }
    var currentMin = array[0]
    var currentMax = array[0]
    for value in array[1..<array.count] {
        if value < currentMin {
            currentMin = value
        } else if value > currentMax {
            currentMax = value
        }
    }
    return (currentMin, currentMax)
}

if let bounds = minMax2(array: [8, -6, 109,30,300]) {
    print("min is \(bounds.min) and max is \(bounds.max)")
}

func addNumber (_a: Int, _b: Int) -> Int{
    return _a + _b
}

func Multipy (_a: Int, _b: Int) -> Int{
    return _a * _b
}

print(Multipy(_a: 10, _b: 20))

let names = ["Dalim", "Tanim", "Ashraful", "Mashrafi","Mushfiq"]

func backward (_s1: String, _s2: String) -> Bool{
    return _s1 < _s2
}

var reverseNames = names.sorted(by: backward)

print(reverseNames)

// Swift Closure Expression, Enumaration

