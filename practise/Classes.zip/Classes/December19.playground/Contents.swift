import UIKit

let age = 30
let name = "Karim"
let ss = name + " is " + String(age) // integer to string print(ss)

print(ss)

let ss2 = "\(name) is \(String(age))"

print(ss2)

// Empty string check
let check = "A"
if check.isEmpty {
print("Its empty") }
else{
print("Not empty") }

//compare string
var v1 = "Test"
var v2 = "test"
if v1==v2 {
    print("Equal String")
}else{
     print("not equal")
}
// Array and Empty array
var SomeArray = [Int]()
SomeArray.append(4)
print(SomeArray.count)

var RA = Array(repeating: 3.0, count: 3)
print(RA)
var RA2 = Array(repeating: 2.0, count: 3)
print(RA2 + RA)

// String type Array

var ShopList : [String] = ["Milk", "Meat", "Beef"]


if ShopList.isEmpty {
    print("Array is Empty")
}else{
    print("Not Empty")
}
ShopList.append("Flour")
ShopList += ["Rice","1000"]
ShopList.insert("Apple", at: 6)
//ShopList.remove(at: 0)
//ShopList.removeLast()
print(ShopList)

for item in ShopList {
    print(item)
}

for (index,value) in ShopList.enumerated() {
    print("Item \(index + 1): \(value)")
}

// Set
let oddNumember: Set = [1,3,5,7,9]
let evenNumber: Set = [2,4,6,8]

print(oddNumember.union(evenNumber).sorted())

// Dictionary
var dic10 = ["Tanim":30, "Karim":39, "Rahim":45]
for dic in dic10 {
print(dic.value)
print(dic.key)
}

var airports: [String: String] = ["XYZ":"ABC","Bangladesh":"SIA","Japan": "Tokio"]
for dic1 in airports {
print(dic1.value)
print(dic1.key)
}

if let AirportName = airports["XYZ"]{
    print("The airport Name is \(AirportName)")
}else{
    print("Name not available")
}

for airportCode in airports.keys{
    print("Airport Keys \(airportCode)")
}

for airportName in airports.values{
    print("Airport Names \(airportName)")
}

let names = ["Kamal", "Rahim", "Monir", "Masud"]
for name in names{
    print("Hello \(name)")
}

let numberofLegs = ["spider": 8, "ant": 6, "cat": 4]

for (animalName,legCount) in numberofLegs {
    print("\(animalName) have \(legCount) legs")
}

for index in 1...10{
    print("Items \(index)")
}

let base = 3
let power = 10
var ans = 1

for _ in 1...power {
    ans *= base
}
print("\(base) to the power \(power) is \(ans)")

let minInterval = 5
let minute = 60

for ticMark in stride(from: 0, to: minute, by: minInterval) {
    print(ticMark)
}

let hour = 12
let hourInterval = 3

for tickMark in stride(from: 3, through: hour, by: hourInterval) {
    print(tickMark)
}

// While loop

var indx = 10

while indx < 11 {
    print("The value is \(indx)")
    indx = indx + 1
}
