//
//  ViewController.swift
//  January12
//
//  Created by Tanim on 12/1/20.
//  Copyright © 2020 USER. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var btn1: UIButton!
    @IBOutlet weak var txt1: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        btn1.layer.cornerRadius = 10
        btn1.layer.borderColor = UIColor(red:0.99, green:0.03, blue:0.14, alpha:1.0).cgColor
        btn1.layer.borderWidth = 1
    }

    @IBAction func unwindToHome(_ sender: UIStoryboardSegue){}
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let SVC = segue.destination as! SecondVC
        SVC.TSecond = (txt1.text!)
        txt1.text = ""
    }

}

