//
//  CollectionViewCell.swift
//  TabViewMe
//
//  Created by Newgen Brl on 23/1/20.
//  Copyright © 2020 Newgen Brl. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var img: UIImageView!
    @IBOutlet weak var title: UILabel!
    @IBOutlet weak var price: UILabel!
    
    func getCollectionData(data: Item){
        img.image = data.img
        title.text = data.title
        price.text = String(data.price!)
    }
}
