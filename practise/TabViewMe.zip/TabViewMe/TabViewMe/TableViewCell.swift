//
//  TableViewCell.swift
//  TabViewMe
//
//  Created by Newgen Brl on 23/1/20.
//  Copyright © 2020 Newgen Brl. All rights reserved.
//

import UIKit

class TableViewCell: UITableViewCell {

    @IBOutlet weak var img: UIImageView!
    @IBOutlet weak var title: UILabel!
    @IBOutlet weak var price: UILabel!
    
    
    func getTableData(tableData: Item){
        img.image = tableData.img
        title.text = tableData.title
        price.text = String(tableData.price!)
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
