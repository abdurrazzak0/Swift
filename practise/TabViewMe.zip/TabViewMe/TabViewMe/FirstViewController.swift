//
//  FirstViewController.swift
//  TabViewMe
//
//  Created by Newgen Brl on 23/1/20.
//  Copyright © 2020 Newgen Brl. All rights reserved.
//

import UIKit

class FirstViewController: UIViewController {
    var tableData: [Item] = []
    @IBOutlet weak var itemTableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        tableData = setDatbleData()
        // Do any additional setup after loading the view.
    }

    func setDatbleData()->[Item] {
        var tempTableArray : [Item] = []
        let v1 = Item(img: #imageLiteral(resourceName: "watch5"), title: "Watch", price: 1950.26, desc: "asdfasf")
        let v2 = Item(img: #imageLiteral(resourceName: "watch6"), title: "Watch", price: 1950.26, desc: "asdfasf")
        let v3 = Item(img: #imageLiteral(resourceName: "watch2"), title: "Watch", price: 1950.26, desc: "asdfasf")
        let v4 = Item(img: #imageLiteral(resourceName: "watch1"), title: "Watch", price: 1950.26, desc: "asdfasf")
        let v5 = Item(img: #imageLiteral(resourceName: "watch2"), title: "Watch", price: 1950.26, desc: "asdfasf")
        let v6 = Item(img: #imageLiteral(resourceName: "watch9"), title: "Watch", price: 1950.26, desc: "asdfasf")
        let v7 = Item(img: #imageLiteral(resourceName: "watch1"), title: "Watch", price: 1950.26, desc: "asdfasf")
        let v8 = Item(img: #imageLiteral(resourceName: "watch7"), title: "Watch", price: 1950.26, desc: "asdfasf")
        let v9 = Item(img: #imageLiteral(resourceName: "watch8"), title: "Watch", price: 1950.26, desc: "asdfasf")
        let v10 = Item(img: #imageLiteral(resourceName: "watch1"), title: "Watch", price: 1950.26, desc: "asdfasf")
        tempTableArray.append(v1)
        tempTableArray.append(v2)
        tempTableArray.append(v3)
        tempTableArray.append(v4)
        tempTableArray.append(v5)
        tempTableArray.append(v6)
        tempTableArray.append(v7)
        tempTableArray.append(v8)
        tempTableArray.append(v9)
        tempTableArray.append(v10)
        return tempTableArray
    }
}
extension FirstViewController : UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tableData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let path = tableData[indexPath.row]
        let cell = itemTableView.dequeueReusableCell(withIdentifier: "TableCell") as! TableViewCell
        cell.getTableData(tableData: path)
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let path = tableData[indexPath.row]
        let cell = storyboard?.instantiateViewController(identifier: "CollectionId") as! CollectionDetailViewController
       cell.collectionSingleData = path
        self.navigationController?.pushViewController(cell, animated: true)
    }
}


