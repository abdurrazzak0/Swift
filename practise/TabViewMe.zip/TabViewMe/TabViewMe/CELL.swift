//
//  CELL.swift
//  TabViewMe
//
//  Created by Newgen Brl on 23/1/20.
//  Copyright © 2020 Newgen Brl. All rights reserved.
//

import UIKit

class CELL: NSObject {

}

class Item{
    var img: UIImage!
    var title: String!
    var price: Float!
    var desc: String!
    
    
    init(img: UIImage, title: String,price: Float, desc: String) {
        self.img = img
        self.title = title
        self.price = price
        self.desc = desc
    }
}
