//
//  SecondViewController.swift
//  TabViewMe
//
//  Created by Newgen Brl on 23/1/20.
//  Copyright © 2020 Newgen Brl. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {
    var collectionArray: [Item] = []
    @IBOutlet weak var itemCollectionView: UICollectionView!
    override func viewDidLoad() {
        super.viewDidLoad()
        let layout = self.itemCollectionView.collectionViewLayout as! UICollectionViewFlowLayout
        layout.sectionInset = UIEdgeInsets(top: 5, left: 5, bottom: 5, right: 5)
        layout.minimumInteritemSpacing = 5
        layout.itemSize = CGSize(width: (self.itemCollectionView.frame.size.width - 20)/2, height: (self.itemCollectionView.frame.size.height/3))
       
        collectionArray = setCollectionData()
        // Do any additional setup after loading the view.
    }

    func setCollectionData()-> [Item]{
        var tempCollectionData : [Item] = []
        let v1 = Item(img: #imageLiteral(resourceName: "img6"), title: "Apple", price: 230.50, desc: "Appale")
        let v2 = Item(img: #imageLiteral(resourceName: "img3"), title: "Orange", price: 250.50, desc: "Appale")
        let v3 = Item(img: #imageLiteral(resourceName: "img1"), title: "Apple", price: 280.50, desc: "Appale")
        let v4 = Item(img: #imageLiteral(resourceName: "img5"), title: "Apple", price: 940.50, desc: "Appale")
        let v5 = Item(img: #imageLiteral(resourceName: "img2"), title: "Apple", price: 120.50, desc: "Appale")
        let v6 = Item(img: #imageLiteral(resourceName: "img4"), title: "Apple", price: 230.50, desc: "Appale")
        let v7 = Item(img: #imageLiteral(resourceName: "img6"), title: "Apple", price: 120.50, desc: "Appale")
        let v8 = Item(img: #imageLiteral(resourceName: "img8"), title: "Apple", price: 230.50, desc: "Appale")
        let v9 = Item(img: #imageLiteral(resourceName: "img1"), title: "Apple", price: 180.50, desc: "Appale")
        let v10 = Item(img: #imageLiteral(resourceName: "img5"), title: "Apple", price: 230.50, desc: "Appale")
        
        tempCollectionData.append(v1)
        tempCollectionData.append(v2)
        tempCollectionData.append(v3)
        tempCollectionData.append(v4)
        tempCollectionData.append(v5)
        tempCollectionData.append(v6)
        tempCollectionData.append(v7)
        tempCollectionData.append(v8)
        tempCollectionData.append(v9)
        tempCollectionData.append(v10)
        return tempCollectionData
        
    }
}

extension SecondViewController : UICollectionViewDelegate, UICollectionViewDataSource{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return collectionArray.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = itemCollectionView.dequeueReusableCell(withReuseIdentifier: "CollectionCell", for: indexPath) as! CollectionViewCell
        cell.getCollectionData(data: collectionArray[indexPath.item])
        cell.layer.borderColor = UIColor.lightGray.cgColor
        cell.layer.borderWidth = 1
        return cell
        
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        print(indexPath.item)
        let cell = itemCollectionView.cellForItem(at: indexPath)
        cell?.layer.borderColor = UIColor.red.cgColor
        cell?.layer.borderWidth = 2
        
        let nv = storyboard?.instantiateViewController(identifier: "CollectionId") as! CollectionDetailViewController
        nv.collectionSingleData = collectionArray[indexPath.item]
        self.navigationController?.pushViewController(nv, animated: true)
    }
    
    func collectionView(_ collectionView: UICollectionView, didDeselectItemAt indexPath: IndexPath) {
        let cell = itemCollectionView.cellForItem(at: indexPath)
        cell?.layer.borderColor = UIColor.lightGray.cgColor
        cell?.layer.borderWidth = 1
    }
}
