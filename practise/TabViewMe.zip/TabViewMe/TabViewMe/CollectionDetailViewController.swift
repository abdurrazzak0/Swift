//
//  CollectionDetailViewController.swift
//  TabViewMe
//
//  Created by Newgen Brl on 23/1/20.
//  Copyright © 2020 Newgen Brl. All rights reserved.
//

import UIKit

class CollectionDetailViewController: UIViewController {
    var collectionSingleData: Item?
    
    @IBOutlet weak var img: UIImageView!
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var lblDesc: UILabel!
    @IBOutlet weak var lblPrice: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
    
        img.image = collectionSingleData?.img
        lblTitle.text = collectionSingleData?.title
        lblPrice.text = String((collectionSingleData?.price)!)
        lblDesc.text = collectionSingleData?.desc
        
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
