//
//  sites.swift
//  January 26
//
//  Created by Tanim on 26/1/20.
//  Copyright © 2020 USER. All rights reserved.
//

import UIKit

class sites: NSObject {
}
class websites{
    var title: String
    var weburl: String
    
    init(title: String, weburl: String){
        self.title = title
        self.weburl = weburl
    }
}
